import requests


def cen(temp):
    temp = (int(temp)-32)*5/9
    print(round(temp))

api_key = "9eb97d66352d8cf98e6ca6332aa31c25"
link = "https://api.openweathermap.org/data/2.5/weather?q=tehran&units=imperial&APPID="+api_key
weather_data = requests.get(link)

temp = round(weather_data.json()['main']['temp'])
# print(temp)
# cen(temp)