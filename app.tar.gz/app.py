from flet import *

def main(page: Page):
    page.add(
        Container(
            alignment=alignment.center,
            expand=True,
            bgcolor="Red",
            content=Text(
                "Welcome Barsam Website :)",
                size=35
            )
        )
    )


app(target=main)