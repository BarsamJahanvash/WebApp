from flet import *
import requests
import flet as ft
from time import sleep

Colors = {"First":"#092327","Second":"#0B5351","Third":"#00A9A5"}


def main( page: Page):
    # App Settings
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    page.bgcolor = Colors["Second"]
    
    def Body():
        # def get_weather(e):
        #     # pr = ft.ProgressRing(width=16, height=16, stroke_width = 2)
        #     # controw.controls = pr
        #     # # page.add(pr)
            
        #     # for i in range(0, 101):
        #     #     pr.value = i * 0.01
        #     #     sleep(0.1)
        #     #     page.update()
        #     # page.controls.remove(pr)
        #     # page.update()
        #     User_Input = (textinput.value).lower()
        #     Check = chekbox.value
        #     def cen(temp):
        #         temp = (int(temp)-32)*5/9
        #         return temp
        #     api_key = "9eb97d66352d8cf98e6ca6332aa31c25"
        #     link = "https://api.openweathermap.org/data/2.5/weather?q="+User_Input+"&units=imperial&APPID="+api_key
        #     weather_data = requests.get(link)
        #     temp = round(weather_data.json()['main']['temp'])
        #     def dd(s):
        #         Container(content=Text(str(s)))
        #     if Check == True:
        #         centemp = round(cen(temp))
        #         print(centemp)
                # contcolmn.controls.append(Text("hi"))
                # MainCont.height = 100
                # page.update()
        #     else:
        #         return temp
        def hell(e):
            # contcolmn.controls.append(Text(""))
            # page.update()
            mmd = textinput.value
            api_key = "9eb97d66352d8cf98e6ca6332aa31c25"
            link = "https://api.openweathermap.org/data/2.5/weather?q="+mmd+"&units=imperial&APPID="+api_key
            # print(link)
            weather_data = requests.get(link)
            temp = round(weather_data.json()['main']['temp'])
            
            contcolmn.controls.append(Text(str(temp)))
            MainCont.height = 200
            page.update()

        MainCont = Container(
            width=500,
            height=700,
            border_radius=15,
            bgcolor = Colors["First"],
            content=(
                contcolmn := Column(
                    controls=[
                        controw := Row(
                            controls=[
                                textinput := TextField(label="Enter The City Name",width=300,border_color=Colors["Third"],color=Colors["Third"],),
                                chekbox := Checkbox(expand=1,label="°C",value=False),ElevatedButton(expand=0,text="Submit",bgcolor=Colors["Third"],color=Colors["First"],on_click=hell)
                            ],
                            alignment=MainAxisAlignment.CENTER,
                            width=700,
                            
                        )
                    ],
                    alignment=MainAxisAlignment.START,
                    auto_scroll=True,
                    width=700,
                    
                )
                
            ),
        padding=20,
        animate=ft.animation.Animation(1000, "bounceOut"),
        
        )
        page.add(MainCont)
    Body()
    page.update()



app(target=main)